// File: app\src\main\java\com\github\bbqribs\pushupstracker\PushupsTrackerApp.kt
package com.github.bbqribs.pushupstracker

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class PushupsTrackerApp : Application()

